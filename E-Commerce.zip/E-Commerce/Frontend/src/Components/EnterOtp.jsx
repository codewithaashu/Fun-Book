import React, { useState } from "react";
import Navbar from "./Navbar";
import { useLocation, useNavigate } from "react-router";
import Swal from "sweetalert2";
const EnterOtp = () => {
  const [otp1, setOtp1] = useState("");
  const [otp2, setOtp2] = useState("");
  const [otp3, setOtp3] = useState("");
  const [otp4, setOtp4] = useState("");
  const location = useLocation();
  const navigate = useNavigate();
  const { email, otp } = location.state;
  const verifyAccount = () => {
    if (location.state !== null) {
      const enteredOtp = Number(otp1 + "" + otp2 + "" + otp3 + "" + otp4);
      if (enteredOtp == otp) {
        navigate("/changepassword", {
          state: {
            email: email,
          },
        });
      } else {
        Swal.fire({
          title: "Error!",
          text: "OTP is not matched. Try Again",
          icon: "error",
          confirmButtonText: "Cool",
        });
      }
    }
  };
  return (
    <>
      {location.state != null ? (
        <>
          <Navbar />

          {/*  */}
          <div className="reset-box">
            <div className="reset-main-box" style={{ minWidth: "320px" }}>
              <div className="reset-password-cont">
                <div className="recovery-heading">
                  <div className="otp-img">
                    <img
                      src="https://constant.myntassets.com/pwa/assets/img/3a438cb4-c9bf-4316-b60c-c63e40a1a96d1548071106233-mobile-verification.jpg"
                      alt=""
                      width={"90px"}
                      height={"90px"}
                    />
                  </div>
                  <h3
                    style={{
                      marginTop: "20px",
                      fontSize: "20px",
                      fontWeight: "600",
                    }}
                  >
                    Verify with OTP
                  </h3>
                  <p>Sent to {email??"test@gmail.com"}</p>
                </div>
                <div className="otp-cont" style={{ marginTop: "40px" }}>
                  <input
                    type="tel"
                    maxLength={"1"}
                    autoComplete="off"
                    value={otp1}
                    onChange={(e) => setOtp1(e.target.value)}
                  />
                  <input
                    type="tel"
                    maxLength={"1"}
                    autoComplete="off"
                    value={otp2}
                    onChange={(e) => setOtp2(e.target.value)}
                  />
                  <input
                    type="tel"
                    maxLength={"1"}
                    autoComplete="off"
                    value={otp3}
                    onChange={(e) => setOtp3(e.target.value)}
                  />
                  <input
                    type="tel"
                    maxLength={"1"}
                    autoComplete="off"
                    value={otp4}
                    onChange={(e) => setOtp4(e.target.value)}
                  />
                </div>
                <div className="form-group mt-4">
                  <button
                    type="submit"
                    className="loginBtn"
                    onClick={verifyAccount}
                  >
                    Verify Account
                  </button>
                </div>
                <div className="reset-help">
                  <p style={{ fontSize: "12px" }}>
                    <span>Unable to get OTP ? </span>
                    <div
                      style={{ cursor: "pointer" }}
                      onClick={() => navigate("/reset")}
                    >
                      Resend OTP
                    </div>
                  </p>
                </div>
              </div>
            </div>
          </div>
        </>
      ) : (
        <h1>You are not authorised. Please login</h1>
      )}
    </>
  );
};

export default EnterOtp;
