import React, { useState } from 'react'
import Navbar from './Navbar'
import { useLocation, useNavigate } from 'react-router';
import axios from 'axios';
import { BASE_URL } from '../Secret';
import Swal from 'sweetalert2'
//import component and css for toastify
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
const ChangePassword = () => {
    const navigate = useNavigate();
    const [password,setPassword]=useState("");
    const [confirmPassword,setConfirmPassword]=useState("");
    const successToast = (msg) => {
        toast.success(msg, {
          position: "top-right",
          autoClose: 2000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          theme: "colored",
        });
      };
      const location = useLocation();
    const changePassword = async(e)=>{
        e.preventDefault();
        //if password are not matched
        if(password!==confirmPassword){
            Swal.fire({
                title: 'Error!',
                text: 'Password and Confirm password are not matched',
                icon: 'error',
                confirmButtonText: 'Cool'
              })  
        }else{
            const {email}=location.state; 
        //if password is matched then send email and password to backend
        const res = await axios.post(`${BASE_URL}/product/changepassword`,{
            email,
            password
        }).catch((err)=>{
            console.log(err);
        });
        Swal.fire({
            title: 'Success!',
            text: "Password is successfully changed",
            icon: 'success',
           
          })    
        navigate("/login")        
        }

    }
  return (
    <>  
        <Navbar/>

        {/*  */}
        <div className="reset-box">
            <div className="reset-main-box">
                <div className="reset-password-cont">
                    <div className="recovery-heading">
                        <h2>Reset Password</h2>
                    </div>
                    <form className='form-box' autoComplete="off" onSubmit={changePassword}>
                        <div className="form-group" >
                            <label htmlFor="" style={{color:"#ff3e6c"}}>New Password</label>
                            <input type="password" name="password" autoComplete='false' placeholder='Enter new Password' value={password} onChange={(e) => setPassword(e.target.value)} style={{width:"100%"}} />
                        </div>
                        <div className="form-group" >
                        <label htmlFor="" style={{color:"green"}}>Confirm Password</label>
                            <input type="password" name="password" autoComplete='false' placeholder='Confirm your new Password' value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} style={{width:"100%"}} />
                        </div>
                        <div className="form-group my-4">
                            <button type='submit' className="loginBtn">RESET PASSWORD</button>
                        </div>
                    </form>
                    <div className="reset-help">
                        <p style={{fontSize:"12px"}}>
                            <span>Unable to reset password?</span>
                            <a href="https://www.linkedin.com/in/ashishranjan1626/" target='_blank'>Get help</a>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </>)
}

export default ChangePassword