import React from "react";
import Navbar from "./Navbar";
import PrivacyContentDB from "./PrivacyContentDB";
import Footer from "./Footer";
const PrivacyPolicy = () => {
  return (
    <>
      <Navbar />

      {/*  */}
      <div className="privacy-main-box">
        <div className="privacy-heading">Privacy Policy</div>
        {PrivacyContentDB.map((curr, index) => {
          return (
            <div className="privacy-content-box" key={index}>
              <h6 className="privacy-content-heading">{curr.heading}</h6>
              <p className="privacy-description">{curr.description}</p>
            </div>
          );
        })}
      </div>

      <Footer/>
    </>
  );
};

export default PrivacyPolicy;
