import React, { useState } from 'react'
import Navbar from './Navbar'
import axios from 'axios'
import { BASE_URL } from '../Secret'
import { useNavigate } from 'react-router'
import Swal from 'sweetalert2';
//import component and css for toastify
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
const Reset = () => {
    const navigate = useNavigate();
    const [email,setEmail]=useState("");
    
    const errorToast = (msg) => {
        toast.error(msg, {
          position: "top-right",
          autoClose: 3000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          theme: "colored",
        });
      };

    const otpGenerate = async(e)=>{
        e.preventDefault();
        //check this email's user is present or not
        const response = await axios.get(`${BASE_URL}/product/user/?email=${email}`) 
        if(response.data.msge==="user not exist"){
            errorToast("User is not found.");
        }else{
            //generate random otp
            const otp = Math.floor(Math.random() * 9000 + 1000);
            //it will send email and otp to backend
            //so we need an api
            const res = await axios.post(`${BASE_URL}/product/generateotp`,{
                email : email,
                otp:otp
            }).catch((err)=>console.log(err));
            if(res.data.message==="Email sent succesfuly"){
                navigate("/enterotp",{
                    state:{
                        email:email,
                        otp:otp
                    }
                })
            }else{
                Swal.fire({
                    title: 'Error!',
                    text: 'Otp is not send. Try Again',
                    icon: 'error',
                    confirmButtonText: 'Cool'
                  })  
            }
        }
    }
  return (
    <>  
        <Navbar/>

        {/*  */}
        <div className="reset-box">
            <div className="reset-main-box">
                <div className="reset-password-cont">
                    <div className="recovery-heading">
                        <h2>Reset Password</h2>
                        <p>Enter your email and we’ll send OTP on your email to reset your password.</p>
                    </div>
                    <form className='form-box' autoComplete="off" onSubmit={otpGenerate}>
                        <div className="form-group" >
                            <input type="text" name="email" autoComplete='false' placeholder='Email Address' value={email} onChange={(e) => setEmail(e.target.value)} style={{width:"100%"}} />
                        </div>
                        <div className="form-group">
                            <button type='submit' className="loginBtn">SEND OTP</button>
                        </div>
                    </form>
                    <div className="reset-help">
                        <p style={{fontSize:"12px"}}>
                            <span>Unable to reset password?</span>
                            <a href="https://www.linkedin.com/in/ashishranjan1626/" target='_blank'>Get help</a>
                        </p>
                    </div>
                </div>
            </div>
        </div>
        <ToastContainer/>
    </>
  )
}

export default Reset;