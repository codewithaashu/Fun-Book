import React, { useEffect } from "react";
import axios from "axios";
import { useLocation } from "react-router";
import { BASE_URL } from "../Secret";
import { useDispatch, useSelector } from "react-redux";
import { Link } from "react-router-dom";
import { setUser } from "../Redux/Action";
import Spinner from "./Spinner";
import App from "../App";
const LoginHome = () => {
  const dispatch = useDispatch();
  const user = useSelector((state) => state.setUserFunc.user);
  console.log(user);
  const location = useLocation();
  console.log(location.state.phone);
  useEffect(() => {
    return async () => {
      const user = await axios
        .get(`${BASE_URL}/product/user/?phone=${location.state.phone}`)
        .catch((err) => {
          console.log("error is : " + err);
        });
      dispatch(setUser(user.data.user));
    };
  }, []);

  return <>{user.length === 0 ? <Spinner /> : <App />}</>;
};

export default LoginHome;
