import React, { useState,useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useLocation, useNavigate } from "react-router-dom";
import axios from "axios";
import Navbar from './Navbar';
import Spinner from './Spinner';
import ProductCard from './ProductCard';
import Footer from './Footer';
import { fetchSearchProduct, removeSelectedProduct } from "../Redux/Action";
import { BASE_URL } from "../Secret";
import "react-toastify/dist/ReactToastify.css";
const SearchProduct = () => {
    const navigate = useNavigate();
    const location = useLocation();
    const searchQuery = location.state.searchQuery;
    const dispatch = useDispatch();
    const fetchSearchItem = async (search) => {
        const item = await axios
        .get(`${BASE_URL}/product/search/${search}`)
        .catch((err) => console.log(err));
        if (item.data.length === 0) {
          navigate("/searchempty",{
            state:{
                searchQuery:search
            }
          })
        } else {
            dispatch(fetchSearchProduct(item.data));
        }
      };
    useEffect(() => {
        if (searchQuery && searchQuery !== "") {
            fetchSearchItem(searchQuery)
        }
        return () => {
            dispatch(removeSelectedProduct());
        }
    }, [searchQuery])
    
    const searchItem = useSelector((state)=>state.fetchSearchProductFunc.product);
  return (
        <>
            <Navbar />
            {
                searchItem.length === 0 ? (
                    <Spinner />
                ) : (
                    <>
                        <div className="row row-cols-1 row-cols-sm-3 row-cols-md-5 row-cols-lg-6 mt-5 card-box1">
                            <ProductCard data={searchItem} />
                        </div>
                        <Footer />

                    </>

                )
            }

        </>
  )
}

export default SearchProduct