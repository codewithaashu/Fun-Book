import React from "react";
import Navbar from "./Navbar";
import { Link, useLocation } from "react-router-dom";
const SearchEmpty = () => {
    const location = useLocation();
    const searchQuery = location.state.searchQuery;
    console.log(searchQuery);
  return (
    <>
      <Navbar />
      <div className="container-fluid my-5" style={{display:"flex",flexDirection:"column",alignItems:"center"}}>
        <div>You searched for <span style={{color:"#3466e8",fontWeight:"600"}}>{searchQuery}</span> 
        </div>
        <div className="my-5">
          <img
            src="https://constant.myntassets.com/web/assets/img/11488523304066-search404.png"
            alt="Empty Box"
          />
        </div>
        <h4 className="text-center mt-2 search-h4">We couldn't find any matches! </h4>
        <div className="text-center search-p">
        Please check the spelling or try searching something else
        </div>
        <div className="mt-5">
            <Link
              to={"/"}
              className="addToBtn-empty-btn"
              style={{ color: "white", background: "#ff3e6c" }}
            >
              CONTINUE SHOPPING
            </Link>
          </div>
      </div>
    </>
  );
};

export default SearchEmpty;
