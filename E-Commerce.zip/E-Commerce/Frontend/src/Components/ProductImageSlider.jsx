import React from "react";
import { Carousel } from "react-responsive-carousel";
import "react-responsive-carousel/lib/styles/carousel.min.css";
const ProductImageSlider = ({ imgArr }) => {
  let screenWidth = window.screen.width;
  return (
    <>
      <div className="carousel-wrapper" style={{width:"70%"}}>
        <Carousel
          infiniteLoop
          useKeyboardArrows
          autoPlay
          interval={2000}
          showStatus={false}
          showThumbs={screenWidth > 700 ? true : false}
          showArrows={false}
        >
          {imgArr.map((curr, index) => {
            return (
              <div key={index}>
                <img
                  src={curr}
                  style={{ maxWidth: "416px", maxHeight: "75vh" }}
                />
              </div>
            );
          })}
        </Carousel>
      </div>
    </>
  );
};

export default ProductImageSlider;
