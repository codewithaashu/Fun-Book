import React from 'react'
import Navbar from './Navbar'
import RegisterPage from './RegisterPage'

const Register = () => {
  return (
    <>
    <Navbar/>
    <RegisterPage/>
    </>
  )
}

export default Register