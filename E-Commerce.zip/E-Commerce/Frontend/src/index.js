import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';
import reportWebVitals from './reportWebVitals';
import {
  createBrowserRouter,
  RouterProvider,
} from "react-router-dom";
import Error from './Components/Error';
import { Provider } from 'react-redux';
import store from './Redux/Store';
import CategoryProduct from './Components/CategoryProduct';
import ProductDetails from './Components/ProductDetails';
import Login from './Components/Login';
import Register from './Components/Register';
import Wishlist from './Components/Wishlist';
import AddToBag from './Components/AddToBag';
import SearchProduct from './Components/SearchProduct';
import ProductListing from './Components/AllProductListing';
import ConfirmOrder from './Components/ConfirmOrder';
import SearchEmpty from './Components/SearchEmpty';
import LoginHome from './Components/LoginHome';
import PrivacyPolicy from './Components/PrivacyPolicy';
import Reset from './Components/Reset';
import EnterOtp from './Components/EnterOtp';
import ChangePassword from './Components/ChangePassword';

const router = createBrowserRouter([
  {
    path: "/",
    element: <App />,
    errorElement: <Error />
  },
  {
    path:"/product",
    element:<ProductListing/>
  },
  {
    path: "/categories/:category",
    element: <CategoryProduct/>,
    errorElement: <Error />
  },
  {
    path:"/products/:id",
    element:<ProductDetails/>
  },
  {
    path:"/search",
    element:<SearchProduct/>
  },
  {
    path:"/searchempty",
    element:<SearchEmpty/>
  },
  {
    path:"/login",
    element:<Login/>
  },
  {
    path:"/loginHome",
    element:<LoginHome/>
  },
  {
    path:"/register",
    element:<Register/>
  },
  {
    path:"/wishlist",
    element:<Wishlist/>
  },
  {
    path:"/addtobag",
    element:<AddToBag/>
  },{
    path:"/confirmorder",
    element:<ConfirmOrder/>
  },{
    path:"/privacy",
    element:<PrivacyPolicy/>
  },
  {
    path:"/reset",
    element:<Reset/>
  },{
    path:"/enterotp",
    element:<EnterOtp/>
  },{
    path:"/changepassword",
    element:<ChangePassword/>
  }
]);
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <Provider store={store}>
      <RouterProvider router={router} />
    </Provider>
  </React.StrictMode>
);

// If you want to start measuring performance in your app, pass a function
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
