// export const BASE_URL = "https://ecommercehost.onrender.com";
export const BASE_URL = "http://localhost:5000";
export const RAZORPAY_KEY_ID= "rzp_live_3FASSiTgMoD6zM";
export const RAZORPAY_KEY_SECRET = "4z8X6XIBIySr2nZCdrzb1CmV";